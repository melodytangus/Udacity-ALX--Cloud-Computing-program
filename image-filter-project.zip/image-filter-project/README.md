# Udagram Image Filtering Microservice


###  Domain 

http://imagefilter-env.eba-y3vmsbkv.us-east-1.elasticbeanstalk.com/
